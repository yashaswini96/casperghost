Do you need help or have a question? Please come chat in our forum: https://forum.ghost.org 👫.

If you're filing a bug 🐛, please include the following information:

### Screenshot

![]()

### Steps to Reproduce
 
 1. This is the first step
 2. This may be the post content used to cause an issue...

### Technical details

* Casper Version:
* Ghost Version:
* Browser Version:
* OS Version:
